# Laporan Proyek Machine Learning - Fakhri Djamaris

## Domain Proyek

Analisis prediktif harga saham merupakan aspek krusial dalam industri keuangan dan investasi. BMW (Bayerische Motoren Werke AG) sebagai salah satu produsen mobil premium terbesar di dunia memiliki pergerakan saham yang menarik untuk dianalisis. Prediksi harga saham dapat membantu investor dalam mengambil keputusan investasi yang lebih informed.

Dalam era digital saat ini, penggunaan machine learning untuk memprediksi harga saham telah menjadi pendekatan yang semakin populer karena kemampuannya dalam mengidentifikasi pola dan tren dari data historis.

[Stock Market Prediction with Historical Time Series Data and Sentimental Analysis of Social Media Data](https://ieeexplore.ieee.org/document/9121121) menunjukkan bahwa meskipun pasar saham cenderung efisien, masih terdapat pola-pola yang dapat diprediksi menggunakan teknik machine learning.

## Business Understanding

### Problem Statements

1. Bagaimana cara memprediksi harga penutupan (Close price) saham BMW berdasarkan data historis?
2. Seberapa akurat model machine learning dalam memprediksi harga saham BMW?
3. Fitur apa saja yang memiliki pengaruh signifikan terhadap prediksi harga saham?

### Goals

1. Mengembangkan model machine learning yang dapat memprediksi harga penutupan saham BMW
2. Mengukur dan membandingkan performa berbagai algoritma machine learning untuk mendapatkan prediksi yang optimal
3. Mengidentifikasi dan menganalisis fitur-fitur yang berpengaruh terhadap pergerakan harga saham

### Solution Statements

1. Mengimplementasikan tiga algoritma machine learning:
   - K-Nearest Neighbors (KNN)
   - Random Forest
   - Linear Regression
2. Melakukan optimasi model dengan:
   - Feature scaling menggunakan StandardScaler
   - Hyperparameter tuning untuk model Random Forest
3. Menggunakan metrics MSE (Mean Squared Error) untuk evaluasi model

## Data Understanding

Dataset yang digunakan adalah data historis saham BMW dari [Kaggle](https://www.kaggle.com/datasets/mhassansaboor/bmw-stock-data-1996-2024)yang mencakup informasi harga harian dan volume perdagangan BWM dari tahun 1996-2024. Dataset ini memiliki beberapa fitur utama:

### Variabel-variabel pada dataset:

- Date: Tanggal perdagangan
- Open: Harga pembukaan saham
- High: Harga tertinggi saham pada hari tersebut
- Low: Harga terendah saham pada hari tersebut
- Close: Harga penutupan saham
- Adj_Close: Harga penutupan yang telah disesuaikan
- Volume: Volume perdagangan saham

### Exploratory Data Analysis (EDA)

1. Analisis Korelasi:
   - Terdapat korelasi yang sangat kuat (>0.9) antara harga Open, High, Low, dan Close
   - Volume memiliki korelasi negatif yang lemah dengan harga
2. Analisis Tren:
   - Visualisasi time series menunjukkan tren pergerakan harga saham
   - Identifikasi pola musiman dan tren jangka panjang

## Data Preparation

1. Handling Missing Values:
   - Pengecekan menunjukkan tidak ada missing values dalam dataset
2. Feature Engineering:
   - Konversi kolom Date menjadi datetime
   - Penggunaan Date sebagai index untuk analisis time series
3. Feature Selection:
   - Menghilangkan fitur Volume karena memiliki korelasi yang lemah
   - Memilih Close sebagai target variable
4. Data Splitting:

   - Train-test split dengan ratio 80:20
   - Random state 321 untuk reproducibility

5. Standardization:
   - Menggunakan StandardScaler untuk normalisasi fitur numerik
   - Scaling diterapkan pada fitur: Adj_Close, High, Low, Open

## Modeling

### 1. K-Nearest Neighbors (KNN)

- Menggunakan n_neighbors=10
- Kelebihan: Sederhana dan efektif untuk data dengan pola non-linear
- Kekurangan: Sensitif terhadap skala fitur

### 2. Random Forest

- Parameters:
  - n_estimators=50
  - max_depth=16
  - random_state=55
- Kelebihan: Robust terhadap overfitting, dapat menangani non-linearitas
- Kekurangan: Komputasi lebih berat

### 3. Linear Regression

- Model linear sederhana
- Kelebihan: Interpretable dan komputasi ringan
- Kekurangan: Hanya dapat menangkap hubungan linear

## Evaluation

Metrik evaluasi yang digunakan adalah Mean Squared Error (MSE). MSE mengukur rata-rata kuadrat selisih antara prediksi dan nilai aktual:

MSE = (1/n) Σ(y_true - y_pred)²

Hasil evaluasi (dalam ribuan):

- KNN: Train MSE = 0.000214, Test MSE = 0.00026
- Random Forest: Train MSE = 0.000033, Test MSE = 0.000217
- Linear Regression: Train MSE = 0.000191 , Test MSE = 0.000192

Linear Regression menunjukkan performa terbaik dengan MSE terendah pada data test, menunjukkan kemampuan generalisasi yang baik.

Rekomendasi Improvement:

1. Feature Engineering tambahan:
   - Technical indicators (Moving averages, RSI)
   - Sentiment analysis dari berita
2. Hyperparameter tuning yang lebih ekstensif
3. Implementasi cross-validation untuk validasi model yang lebih robust
